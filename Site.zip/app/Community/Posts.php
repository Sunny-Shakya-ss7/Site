<?php

namespace App\Community;

use Illuminate\Database\Eloquent\Model;

class Posts extends Model
{
    //
}
