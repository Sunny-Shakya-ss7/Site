<p align="center"><img src="https://toppng.com/public/uploads/preview/leo-logo-png-transparent-leo-club-international-11563053714vpnhp40led.png" width="400"></p>

## About Leo International Club

Leo District Council 325 A2, Nepal is the governing body for the Leo Clubs in the region from Kathmandu to Janakpur under the vision of Leo Club Program.
The Leo District Council 325 A2 is under the Leo Multiple District Council 325, Nepal of International Association of Lions Clubs.

Bagmati Leo Club,
Banepa Leo Club,
Bhaktapur Araniko Leo Club,
Bhaktapur Dibyaswori Leo Club,
Bhaktapur Suryabinayak Leo Club,
Dhanusha Janakpur Leo Club,
Janakpur Monastic Leo Club,
Kabhre Banepa Leo Club,
Kabhre Shankhu Leo Club,
Kathmandu Chabahil Leo Club,
Kathmandu Cindrella Leo Club,
Kathmandu Creation Leo Club,
Kathmadnu Doab Leo Club,
Kathmandu Down Town Leo Club,
Kathmandu Eureka Leo Club,
Kathmandu Horizon Leo Club,
Kathmandu Imperial Leo Club,
Kathmandu Kailash Leo Club,
Kathmandu Kritipur Leo Club,
Kathmandu Peace Leo Club,
Kathmandu Ramechhap Leo Club,
Kathmandu Rays Leo Club,
Kathmandu Regency Leo Club,
Kathmandu Samriddhi Leo Club,
Kathmandu Future Star Leo Club,
Kathmandu Sunrise Arunodaya Leo Club,
Okhaldhunga leo club,
Kathmandu Unique Leo Club,
Kathmandu Vision Leo Club
Bhaktapur Golden Gate Leo Club,
Kathmandu Alka Leo Club,
Kathmandu Pioneer Leo Club,
Kathmandu Himchuli Leo Club,
Kathmandu Central Leo Club,
Kathmandu Dhumbarahi Leo Club,
Nepal Excellence Leo Club,
Kavre Sakhu Leo Club,
Kathmandu Natural Leo Club,
Kathmandu Fellowship Leo Club,
Lalbandi City Leo Club,
Panauti Leo Club,
Sindhuli City Leo Club,
Kathmandu Syenergy Leo Club,
Kathmandu Roshni Leo Club,
Harion Leo Club,
Bhaktapur Rose Village Leo Club,
Kathmandu Capital Leo Club,
Kathmandu Chabahil City Leo Club,
Kathmandu Diamond Leo Club,
Kathmandu Kageshwori Leo Club,
Kathmandu Samriddhi Mega College Chapter Leo Club,
Mount 8848 Leo Club,
Nepal Eco Friendly Leo Club,
Bhaktapur Kedareshwor Leo Club

##Contact us

leodistrict325a2@gmail.com
+977 980 123 5522